это туториал по моей библиотеке
(changed in origin and pushed to shared)